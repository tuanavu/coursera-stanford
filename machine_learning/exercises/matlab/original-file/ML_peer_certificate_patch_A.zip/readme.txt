This patch fixes the "Peer certificate" issue with the submit.m script for Windows-like systems.
The patch was first developed by Liran Moysi.
Instructions:
1) Copy the file "submitWithConfiguration.m" to the "../ex?/lib" folder for each programming exercise.
This will overwrite the existing file.
2) Restart Octave or MATLAB after installing the patch.
